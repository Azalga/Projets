#%%
import os
import sys
import numpy as np
import networkx as nx
from sklearn.neighbors import BallTree
from geopy.geocoders import Nominatim
import xml.etree.ElementTree as ET
import simplekml
import osmnx as ox
from pyproj import Transformer

# === Répertoire racine du script ===
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# === 1. Extraire les caméras ===
def extract_coords_from_kml(file_path):
    tree = ET.parse(file_path)
    root = tree.getroot()
    ns = {'kml': 'http://www.opengis.net/kml/2.2'}
    coords = []
    for placemark in root.findall('.//kml:Placemark', ns):
        point = placemark.find('.//kml:Point/kml:coordinates', ns)
        if point is not None:
            parts = point.text.strip().split(',')
            if len(parts) >= 2:
                lon = float(parts[0])
                lat = float(parts[1])
                coords.append((lat, lon))
    return coords

# === 2. Géocoder une adresse + vérifier Paris ===
def geocode_address(address):
    if not address.strip():
        raise ValueError("Adresse vide. Veuillez saisir une adresse.")
    geolocator = Nominatim(user_agent="camera_route_planner", timeout=10)
    location = geolocator.geocode(address, addressdetails=True)
    if location is None:
        raise ValueError(f"Adresse non trouvée : {address}")
    if not location.raw.get('address', {}).get('city', '').lower() == "paris":
        raise ValueError(f"L'adresse n'est pas dans Paris : {address}")
    return (location.latitude, location.longitude)

# === 3. Trouver la caméra la plus proche ===
def find_closest_camera(point, camera_coords):
    cam_rad = np.radians(np.array(camera_coords))
    point_rad = np.radians(np.array(point).reshape(1, -1))
    tree = BallTree(cam_rad, metric='haversine')
    dist, ind = tree.query(point_rad, k=1)
    return ind[0][0], dist[0][0] * 6371

# === 4. Construire le graphe de caméras ===
def build_camera_graph(camera_coords, max_dist_m=400):
    coords_rad = np.radians(camera_coords)
    tree = BallTree(coords_rad, metric='haversine')
    G = nx.Graph()
    for i, coord in enumerate(camera_coords):
        G.add_node(i, coord=coord)
        ind, dist = tree.query_radius([coords_rad[i]], r=max_dist_m / 6371000, return_distance=True)
        for j, d in zip(ind[0], dist[0]):
            if i != j:
                G.add_edge(i, j, weight=d)
    return G

# === 5. Chemin optimal entre deux caméras ===
def find_best_path(G, start_idx, end_idx):
    path = nx.shortest_path(G, start_idx, end_idx, weight='weight')
    return [G.nodes[n]['coord'] for n in path]

# === 6. Conversion vers itinéraire piéton réaliste ===
def convert_coords_to_pedestrian_route(gps_points, graph_path, output_path):
    print("📂 Chargement du graphe routier local...")
    G = ox.load_graphml(graph_path)

    print("🚶 Calcul de l’itinéraire piéton réaliste...")
    route_nodes = []
    for i in range(len(gps_points) - 1):
        start = gps_points[i]
        end = gps_points[i + 1]
        orig_node = ox.distance.nearest_nodes(G, start[1], start[0])
        dest_node = ox.distance.nearest_nodes(G, end[1], end[0])
        try:
            segment = nx.shortest_path(G, orig_node, dest_node, weight='length')
            route_nodes.extend(segment[:-1])
        except nx.NetworkXNoPath:
            print(f"⚠️ Aucun chemin trouvé entre {start} et {end}")
    route_nodes.append(dest_node)

    print(f"✅ Itinéraire généré avec {len(route_nodes)} nœuds")

    coords_proj = [(G.nodes[n]['x'], G.nodes[n]['y']) for n in route_nodes]
    transformer = Transformer.from_crs(G.graph['crs'], "EPSG:4326", always_xy=True)
    lonlat_coords = [transformer.transform(x, y) for x, y in coords_proj]

    kml = simplekml.Kml()
    line = kml.newlinestring(name="Itinéraire piéton réaliste", coords=lonlat_coords)
    line.style.linestyle.width = 5
    line.style.linestyle.color = simplekml.Color.green
    kml.save(output_path)
    print(f"✅ Fichier exporté : {output_path}")

# === 7. Exécution principale ===
if __name__ == "__main__":
    kml_file = os.path.join(BASE_DIR, "camera.kml")
    graph_file = os.path.join(BASE_DIR, "paris.graphml")
    output_kml_pieton = os.path.join(BASE_DIR, "itineraire_camera_rues.kml")

    try:
        adresse_depart = input("📍 Adresse de départ (Paris uniquement) : ").strip()
        adresse_arrivee = input("📍 Adresse d'arrivée (Paris uniquement) : ").strip()

        pt_depart = geocode_address(adresse_depart)
        pt_arrivee = geocode_address(adresse_arrivee)
    except ValueError as e:
        print(f"⛔ Erreur : {e}")
        sys.exit("💥 Programme stoppé.")

    camera_coords = extract_coords_from_kml(kml_file)
    print(f"✅ {len(camera_coords)} caméras chargées")

    idx_depart, dist_d = find_closest_camera(pt_depart, camera_coords)
    idx_arrivee, dist_a = find_closest_camera(pt_arrivee, camera_coords)

    print(f"🎯 Caméra la plus proche du départ : #{idx_depart} ({dist_d:.2f} km)")
    print(f"🎯 Caméra la plus proche de l'arrivée : #{idx_arrivee} ({dist_a:.2f} km)")

    G = build_camera_graph(camera_coords)
    path_coords = find_best_path(G, idx_depart, idx_arrivee)

    full_route = [pt_depart] + path_coords + [pt_arrivee]
    convert_coords_to_pedestrian_route(full_route, graph_file, output_kml_pieton)
